package com.example.demo.servicios;
import javax.validation.Valid;

import org.springframework.stereotype.Service;
import java.util.List;

import com.example.demo.models.Producto;
import com.example.demo.repositorios.ProductoRepositorio;

@Service
public class ProductoServicio {
	//logica de negocio o empresarial
		//dependencia repository
		private final ProductoRepositorio ep;
		
		public ProductoServicio(ProductoRepositorio productoRepositorio) {
			this.ep = productoRepositorio;
		}

		public Producto insertarVenta(@Valid Producto producto) {
			// TODO Auto-generated method stub
			return ep.save(producto);
		}

		public List<Producto> findAll() {
			// retorna una lista de empleados
			return ep.findAll();
		}

		public void eliminarProducto(Long id) {
			// TODO Auto-generated method stub
			ep.deleteById(id);
}

		public Producto insertarProducto(Producto producto) {
			// TODO Auto-generated method stub
			return ep.save(producto);
			
		} 
}
