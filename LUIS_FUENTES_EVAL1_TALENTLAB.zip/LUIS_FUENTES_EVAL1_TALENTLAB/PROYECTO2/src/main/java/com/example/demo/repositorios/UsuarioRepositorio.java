package com.example.demo.repositorios;


import javax.validation.Valid;
import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.models.Usuario;
import com.example.demo.models.Venta;


@Repository
public interface UsuarioRepositorio extends CrudRepository<Usuario,Long> {

	
     List<Usuario> findAll();
	
	
}
	

