package com.example.demo.repositorios;


import javax.validation.Valid;
import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.models.Producto;
import com.example.demo.models.Venta;


@Repository
public interface ProductoRepositorio extends CrudRepository<Producto,Long> {

	
     List<Producto> findAll();
	
	
}
	
