package com.example.demo.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;


@Entity //representacion de entidad modelo
@Table(name="productos")
public class Producto {
	//id
	@Id //clave primaria
	@GeneratedValue(strategy = GenerationType.IDENTITY)//auto incrementar
	private Long id;
	private String codigo;
	private String nombreProducto;
	private String descripcion;
	private int inventario;
	private int precio;
	
	
     @Column(updatable=false)
     @DateTimeFormat(pattern="yyyy-MM-dd")
       private Date createdAt;
      @DateTimeFormat(pattern="yyyy-MM-dd")
       private Date updatedAt;
	
	public Producto() {
		super();
	}

	public Producto(String codigo, String nombreProducto, String descripcion, Integer inventario, Integer precio) {
		super();
		this.codigo = codigo;
		this.nombreProducto = nombreProducto;
		this.descripcion = descripcion;
		this.inventario = inventario;
		this.precio = precio;
	
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodigo() {
		return codigo;
	}

	public String getNombreProducto() {
		return nombreProducto;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public int getInventario() {
		return inventario;
	}

	public Integer getPrecio() {
		return precio;
	}


	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public void setNombreProducto(String nombreProducto) {
		this.nombreProducto = nombreProducto;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public void setinventario(int inventario) {
		this.inventario = inventario;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	
	
      @PrePersist //se ejecuta antes de que sea insertado
       protected void onCreate(){
         this.createdAt = new Date();
       }
      @PreUpdate // se ejecuta antes de que sea actualizado
      protected void onUpdate(){
         this.updatedAt = new Date();
     }
}
