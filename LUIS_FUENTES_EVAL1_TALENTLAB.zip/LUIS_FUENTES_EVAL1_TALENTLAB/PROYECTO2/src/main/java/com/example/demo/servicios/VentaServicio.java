package com.example.demo.servicios;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import java.util.List;

import com.example.demo.models.Venta;
import com.example.demo.repositorios.VentaRepositorio;



@Service
public class VentaServicio {

	//logica de negocio o empresarial
	//dependencia repository
	private final VentaRepositorio er;
	
	public VentaServicio(VentaRepositorio ventaRepositorio) {
		this.er = ventaRepositorio;
	}

	public Venta insertarVenta(@Valid Venta venta) {
		// TODO Auto-generated method stub
		return er.save(venta);
	}

	public List<Venta> findAll() {
		// retorna una lista de empleados
		return er.findAll();
	}

	public void eliminarVenta(Long id) {
		// TODO Auto-generated method stub
		er.deleteById(id);
	}

	public Venta insertarProductos(Venta venta) {
		// TODO Auto-generated method stub
		return er.save(venta);
		
	}
	}    