package com.example.demo.controlers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

import javax.validation.Valid;

import com.example.demo.models.Venta;
import com.example.demo.servicios.VentaServicio;

@Controller
@RequestMapping("/venta")
public class VentaControler {

		
		//dependencia servicio
		private final VentaServicio gallina;
		
		public VentaControler(VentaServicio ventaService) {
			this.gallina = ventaService;
		}
		
	//@ModelAttribute("empleado") Empleado empleado, ejemplo pasar entidad a un jsp
		@RequestMapping("")
		public String index(@ModelAttribute("venta") Venta venta,Model model ) {
			System.out.println("index");
			
			List<Venta> lista_ventas = gallina.findAll();
			model.addAttribute("lista_productos", lista_ventas);
			
			return "venta.jsp";
		}
		
		@RequestMapping(value="/crear", method = RequestMethod.POST)
		public String crear(@Valid @ModelAttribute("venta") Venta venta) {
			System.out.println("crear "+ venta);
			//llamado a guardar la entidad
		
			Venta vent =  gallina.insertarProductos(venta);
			return "redirect:/venta";
		}
		
		@RequestMapping(value="/actualizar/{id}", method = RequestMethod.GET)
		public String actualizar(@PathVariable("id") Long id) {
			System.out.println("actualizar id: "+ id);
			return "redirect:/";
		}
		
		@RequestMapping(value="/eliminar", method = RequestMethod.POST)
		public String eliminar(@RequestParam("id") Long id) {
			System.out.println("Eliminar id: "+ id);
			gallina.eliminarVenta(id);
			return "redirect:/venta";
		}
		
		
		@RequestMapping(value="/eliminar2/{id}", method = RequestMethod.DELETE)
		public String eliminar2(@PathVariable("id") Long id) {
			System.out.println("Eliminar2 id: "+ id);
			gallina.eliminarVenta(id);
			return "redirect:/venta";
		}
		
		
		@RequestMapping("/buscar")
		public String buxcar() {
			return "redirect:/venta";
		}
	}


